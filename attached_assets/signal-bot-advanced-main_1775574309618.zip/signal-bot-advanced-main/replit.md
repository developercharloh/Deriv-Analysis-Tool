# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Deriv Signal Generator — an automated trading signal system that monitors 8 Synthetic 1s Indices (1HZ10V, 1HZ15V, 1HZ25V, 1HZ30V, 1HZ50V, 1HZ75V, 1HZ90V, 1HZ100V), generates all 8 signal types (OVER/UNDER/RISE/FALL/EVEN/ODD/MATCHES/DIFFERS), and sends signals to Telegram + WhatsApp. Includes a paid subscriber management system with weekly/monthly/6-month/yearly tiers.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + Tailwind CSS + Recharts

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server + Deriv bot engine
│   └── deriv-signals/      # React frontend dashboard
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Features

- Live tick analysis from Deriv WebSocket API (falls back to tick simulator if WS unavailable)
- Signal types: OVER, UNDER, EVEN, ODD, RISE, FALL
- Confidence levels: LOW, MEDIUM, HIGH
- Telegram bot integration for alert delivery
- Real-time SSE stream for live dashboard updates
- Signal history stored in PostgreSQL

## Key Backend Files

- `artifacts/api-server/src/lib/deriv.ts` — Deriv WebSocket client
- `artifacts/api-server/src/lib/analysis.ts` — Signal analysis engine
- `artifacts/api-server/src/lib/bot.ts` — Bot orchestration + SSE broadcasting
- `artifacts/api-server/src/lib/telegram.ts` — Telegram message sender
- `artifacts/api-server/src/lib/simulator.ts` — Tick simulator fallback
- `artifacts/api-server/src/routes/signals.ts` — Signal + SSE routes
- `artifacts/api-server/src/routes/settings.ts` — Settings CRUD + Telegram test

## Database Schema

- `signals` — Saved trading signals (market, symbol, digit, price, signalType, confidence)
- `bot_settings` — Bot config (telegramBotToken, chatId, selectedMarkets, signalTypes, isRunning)

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json`. Run typechecks from root with `pnpm run typecheck`.

## API Routes

- `GET /api/healthz` — Health check
- `GET /api/signals?limit=N` — Signal history
- `GET /api/signals/stream` — SSE live stream
- `GET /api/settings` — Get settings
- `PUT /api/settings` — Update settings
- `POST /api/settings/test-telegram` — Test Telegram connection
